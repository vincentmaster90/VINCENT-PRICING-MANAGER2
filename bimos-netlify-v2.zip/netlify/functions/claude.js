// netlify/functions/claude.js
// Secure proxy to the Anthropic API.
// The API key is read from a Netlify environment variable (ANTHROPIC_API_KEY)
// and is NEVER exposed to the browser.

exports.handler = async (event) => {
  // Allow CORS for same-origin use
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
  };

  // Handle preflight
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "Server not configured: ANTHROPIC_API_KEY is missing in Netlify environment variables." }),
    };
  }

  try {
    const incoming = JSON.parse(event.body || "{}");

    // Forward the request body to Anthropic. We add the required headers here.
    const anthropicHeaders = {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    };

    // If the request uses the web_search tool, the beta header may be required.
    const bodyStr = JSON.stringify(incoming);
    if (bodyStr.includes("web_search")) {
      anthropicHeaders["anthropic-beta"] = "web-search-2025-03-05";
    }

    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: anthropicHeaders,
      body: bodyStr,
    });

    const text = await resp.text();
    return { statusCode: resp.status, headers, body: text };
  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "Proxy error: " + (err && err.message ? err.message : String(err)) }),
    };
  }
};
